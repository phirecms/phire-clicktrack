<?php

return [
    'clicks' => [
        'index'
    ]
];